const fs = require('fs');
const util = require('util');

const unlinkFile = util.promisify(fs.unlink);

async function deleteFile(filePath) {
  try {
    await unlinkFile(filePath);
    console.log(`${filePath} was deleted`);
  } catch (error) {
    console.error(`Error deleting file: ${error}`);
  }
}

deleteFile('./files/sample.txt');
