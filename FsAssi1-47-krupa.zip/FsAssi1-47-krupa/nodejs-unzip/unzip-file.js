const fs = require('fs');
const unzipper = require('unzipper');

function unzipFile(zipPath, extractTo) {
  fs.createReadStream(zipPath)
    .pipe(unzipper.Extract({ path: extractTo }))
    .on('close', () => {
      console.log('Extraction complete');
    });
}

unzipFile('./folder-to-zip.zip', './extracted-folder');
