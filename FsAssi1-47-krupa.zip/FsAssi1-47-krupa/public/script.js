document.getElementById('btn').addEventListener('click', () => {
    fetch('/gethello')
      .then(response => response.text())
      .then(data => {
        document.getElementById('response').innerText = data;
      })
      .catch(error => console.error('Error:', error));
  });