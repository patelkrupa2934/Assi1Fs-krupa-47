const fs = require('fs');
const archiver = require('archiver');

function zipFolder(sourceFolder, outPath) {
  const output = fs.createWriteStream(outPath);
  const archive = archiver('zip', { zlib: { level: 9 } });
  
  output.on('close', () => {
    console.log(`${archive.pointer()} total bytes written`);
  });

  archive.pipe(output);
  archive.directory(sourceFolder, false);
  archive.finalize();
}

zipFolder('./folder-to-zip', './folder-to-zip.zip');
