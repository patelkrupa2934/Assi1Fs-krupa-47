const mysql = require('mysql2/promise');

async function runDatabase() {
  const connection = await mysql.createConnection({
    host: 'localhost',
    user: 'root', // Use your MySQL credentials
    password: 'password', // Replace with your MySQL password
    database: 'testdb'
  });

  // Insert a new record
  await connection.execute(
    'INSERT INTO employees (name, age, position) VALUES (?, ?, ?)', 
    ['John Doe', 30, 'Developer']
  );

  // Fetch all records
  const [rows] = await connection.execute('SELECT * FROM employees');
  console.log('Employee records:', rows);

  await connection.end();
}

runDatabase();
