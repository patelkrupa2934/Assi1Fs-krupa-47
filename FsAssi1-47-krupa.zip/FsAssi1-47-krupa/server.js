const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Use body parser for handling POST request body
app.use(bodyParser.urlencoded({ extended: true }));

// Handle GET request
app.get('/hello', (req, res) => {
  res.send('Hello, GET request received!');
});

// Handle POST request
app.post('/submit', (req, res) => {
  res.send(`Hello, POST request received with data: ${JSON.stringify(req.body)}`);
});

// Start server
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});

// Route /gethello
app.get('/gethello', (req, res) => {
    res.send('Hello NodeJS!!');
  });
  