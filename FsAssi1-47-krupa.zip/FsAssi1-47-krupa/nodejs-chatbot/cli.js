const readline = require('readline');
const chatbot = require('./chatbot');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

rl.setPrompt('You: ');
rl.prompt();

rl.on('line', (input) => {
  const response = chatbot(input);
  console.log(`Bot: ${response}`);
  rl.prompt();
});
