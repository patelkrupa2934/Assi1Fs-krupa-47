// chatbot.js
const responses = {
    "hello": "Hi! How can I assist you?",
    "bye": "Goodbye!",
    "help": "I can assist with general queries."
  };
  
  function chatbot(input) {
    return responses[input.toLowerCase()] || "I didn't understand that.";
  }
  
  module.exports = chatbot;
  